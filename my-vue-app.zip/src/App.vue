<script setup>

</script>

<template>
  <!-- <div class="bg-pink-200 m-10 p-5"> -->
    <!-- <el-row class="mb-4">
        <el-button>Default</el-button>
        <el-button type="primary">Primary</el-button>
        <el-button type="success">Success</el-button>
        <el-button type="info">Info</el-button>
        <el-button type="warning">warning</el-button>
        <el-button type="danger">Danger</el-button>
    </el-row> -->
    <!-- <button class="btn">按钮</button>
  </div>   -->
  <RouterView></RouterView> 
</template>
  

<style scoped>
.btn{
  @apply bg-purple-300  px-5 py-2 rounded-full 
  hover:(bg-purple-900 text-light-300)
  focus:(ring-8 ring-pink-500)
  transition-all duration-400
}
</style>
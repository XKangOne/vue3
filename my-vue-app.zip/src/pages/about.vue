<script setup>

</script>

<template>
    <div>
        about
    </div>
</template>

<style scoped>

</style>
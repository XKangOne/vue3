<script setup>
import { ref } from 'vue';
import { useCookies } from '@vueuse/integrations/useCookies';
import { storeToRefs } from 'pinia';
import { useAdmin } from '../store';

const store =useAdmin()
const cookie = useCookies()
// const token = ref(cookie.get('admin-token'))
const {token ,admin} =storeToRefs(store)
</script>

<template>
    <div>
        <h2>index</h2>
        <p>{{ token }}</p>
        <p>{{ admin.nickname }}</p>
    </div>
</template>

<style scoped>

</style>